/* Includes -- App -----------------------------------------------------------*/
#include "sequenceDrumControl.h"

/* References ----------------------------------------------------------------*/
#define UNUSED(expr) do { (void)(expr); } while (0)
#define SAFETY_LIMIT 10000 //Max index in case of unterminated loops

///* Functions -----------------------------------------------------------------*/
//void TestSequencePlayer::listSequence(void)
//{
//    listSequence(true, 0, SEQ_LEN - 1);
//}
