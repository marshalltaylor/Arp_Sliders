/* Includes -- Test ----------------------------------------------------------*/
#include "sequenceTest.h"

sequence_t testSequence001 =
{
    1,
    36,
    {false, -1, true, 0, -1, 0, 0},
    {
        {SEG_FLAG_USED | SEG_FLAG_ON, 120, 300, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 121, 300, -0.27}, // This note is a normal advance
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 122, 450, 0.25}, //This one is delayed
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 123, 300, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 124, 300, -1.1}, //This one is BEFORE the earlier one by advance
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 125, 300, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 126, 300, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {SEG_FLAG_USED | SEG_FLAG_ON, 127, 300, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
        {0, 0, 0, 0},
    }
};
