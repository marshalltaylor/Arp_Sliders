#include <iostream>
#include "sequence.h"
//#include "sequenceTest.h"
#include "midi47fx.h"
#include "bsp.h"

#include "poolTest.h"

PoolTest linkedListMem(16, 40);

//extern uint32_t timeo;

//TestSequencePlayer testPlayer;

MidiTestFixture MIDI;

//static seqElement_t wElement = {0, 0, 0, 0};

//void sequenceCallback(bool isNoteOn, sequence_t * seq, seqElement_t * record)
//{
//    printf("*** callback(%d, 0x%02X, %d, %d)\n", isNoteOn, seq->channel, seq->note, record->velocity);
//}

/* Functions -----------------------------------------------------------------*/
int main ()
{
    seqNote_t noteVar;
    UNUSED(noteVar);
    
    linkedListMem.printInfo();
    
    printf("Create a linked list of note objects\n");
    printf("  size calculated as %d bytes\n", (int)sizeof(seqNote_t));
    NoteList noteList(20, sizeof(seqNote_t));
    noteList.setPool(&linkedListMem);
    noteList.printList();

    printf("Add some notes\n");
    noteVar.pitch = 20;
    noteVar.velocity = 100;
    noteVar.length = 24;
    noteVar.accent = 0;
    
    noteList.pushObject(&noteVar);
    noteVar.pitch = 32;
    noteList.pushObject(&noteVar);
    noteVar.pitch = 44;
    noteList.pushObject(&noteVar);
    
    noteList.printList();

}