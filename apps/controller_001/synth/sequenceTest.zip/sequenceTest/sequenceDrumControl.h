#ifndef SEQUENCEDRUMCONTROL_H
#define SEQUENCEDRUMCONTROL_H

/* Includes -- STD -----------------------------------------------------------*/
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* Includes -- App -----------------------------------------------------------*/
#include "sequence.h"

class DrumControl : public SequencePlayer
{
public:
    using SequencePlayer::SequencePlayer;
    
    
    //void listSequence(void);
    //void listSequence(bool listHeader, uint32_t start, uint32_t end);
    //void testBasic(void);
};

#endif
