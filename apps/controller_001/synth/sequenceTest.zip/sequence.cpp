#include <string.h>
#include <stdint.h>
#include <cstdio>

#include "midi47fx.h"
#include "sequence.h"
#include "bsp.h"

// Connect directly to bsp.
#define localPrintf bspPrintf

///* Functions -----------------------------------------------------------------*/
NoteList::NoteList(listIndex_t maxLengthIn, uint16_t dataSizeIn) : LinkedList(maxLengthIn, dataSizeIn)
{
    ((seqNote_t*)&nullObject)->pitch = 33;
    ((seqNote_t*)&nullObject)->velocity = 0;
}

void NoteList::printList(void)
{
    listItemContainer_t * tempCont;
    //our custom type
    seqNote_t * pData;
    tempCont = startObjectPtr;
    pData = (seqNote_t *)tempCont->data;
    localPrintf("\n Pos, number, address, nextObjectAddress\n");
    localPrintf(  "-------------------------\n");
    //Iterate to the depth
    for ( uint8_t i = 0; i < currentPosition; i++ )
    {
        localPrintf("%d, %d, %d, 0x%p, 0x%p\n",
                    i,
                    pData->pitch,
                    pData->velocity,
                    (void*)&tempCont,
                    (void*)tempCont->nextObject);
        
        //move index
        tempCont = tempCont->nextObject;
        pData = (seqNote_t *)tempCont->data;
  }
  localPrintf("\ncurrentPosition: %d\n", currentPosition);
  
}
