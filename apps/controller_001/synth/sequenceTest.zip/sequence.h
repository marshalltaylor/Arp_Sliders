#ifndef SEQUENCE_H
#define SEQUENCE_H

#include <stdint.h>

#include "linkedList.h"

/*
Object usage:

Sequence player
  Sequence
    channel
    info
    data[]
  play info

*/

#define STEPS_PER_BEAT 4
#define QUARTER_PER_SEQUENCE 8
#define SEQ_LEN (STEPS_PER_BEAT * QUARTER_PER_SEQUENCE) //elements in data
#define PULSES_PER_QUARTER 24
#define SUBS_PER_PULSE 20
#define SUBS_PER_SEQ (SUBS_PER_PULSE * PULSES_PER_QUARTER * QUARTER_PER_SEQUENCE)
#define SUBS_PER_RECORD (SUBS_PER_PULSE * PULSES_PER_QUARTER / STEPS_PER_BEAT)

#define SEG_FLAG_USED 0x01
#define SEG_FLAG_ON 0x02

//Array data type
struct seqNote_t
{
  uint8_t pitch;
  uint8_t velocity;
  uint8_t accent;
  float length;
};

class NoteList : public LinkedList
{
public:
    NoteList(listIndex_t maxLengthIn, uint16_t dataSizeIn);
    void printList(void);
};

#endif //SEQUENCE_H
